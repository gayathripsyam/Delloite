package com.pms.deloitte.serviceimpl;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pms.deloitte.dao.ProductDAO;
import com.pms.deloitte.model.Product;
import com.pms.deloitte.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDAO productDAO;
	
	@Override
	@Transactional
	public void addProduct(Product product) {
		productDAO.save(product);
		
	}

	@Override
	public void updateProduct(Product product) {
		if(productDAO.existsById(product.getProductId()))
		{
			productDAO.save(product);
		}
		
	}

	@Override
	public void deleteProduct(int productId) {
		Optional<Product> optionalProduct=productDAO.findById(productId);
		Product product=new Product();
		if(optionalProduct.isPresent())
		{
			product=optionalProduct.get();
		}
		productDAO.delete(product);
	}

	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		Optional<Product> optionalProduct=productDAO.findById(productId);
		Product product=new Product();
		if(optionalProduct.isPresent())
		{
			product=optionalProduct.get();
		}
		return product;
	}

	@Override
	public boolean productExists(int productId) {
		// TODO Auto-generated method stub
		Optional<Product> optionalProduct=productDAO.findById(productId);
		if(optionalProduct.isPresent())
		{
			return true;
		}
		return false;
	 }

	@Override
	public List<Product> listProducts() {
		// TODO Auto-generated method stub
	  List<Product> productlist=(List<Product>)productDAO.findAll();
	  return productlist;
	}

	@Override
	public List<Product> listProducts(String productName) {
		// TODO Auto-generated method stub
     List<Product> productlist=(List<Product>)productDAO.findByProductName(productName);
	 return productlist;
	}

	@Override
	public List<Product> listProducts(int price) {
		// TODO Auto-generated method stub
		 List<Product> productlist=(List<Product>)productDAO.findByPrice(price);
		 return productlist;
	}
          
}
