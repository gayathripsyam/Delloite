package com.pms.deloitte.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.pms.deloitte.model.Product;

@Repository
public interface ProductService {
	
	public void addProduct(Product product);
	public void updateProduct (Product product);
	public void deleteProduct(int productId);
	public Product getProduct(int productId);
	public boolean productExists(int productId);
	public List<Product> listProducts();
	public List<Product> listProducts(String productName);
	public List<Product> listProducts(int price);

}