package com;

public class Message {
	
	private String bodyContent;

	public String getBodyContent() {
		return bodyContent;
	}

	public void setBodyContent(String bodyContent) {
		this.bodyContent = bodyContent;
	}

	@Override
	public String toString() {
		return "Message [bodyContent=" + bodyContent + "]";
	}

	
}
