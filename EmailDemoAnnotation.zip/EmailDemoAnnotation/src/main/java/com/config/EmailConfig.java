package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.Email;
import com.From;
import com.Message;
import com.Subject;
import com.To;

@Configuration
public class EmailConfig {
	
	@Bean
	public To getTo() {
		return new To();
	}
	@Bean
	public From getFrom() {
		return new From();
	}
	@Bean
	public Message getMessage() {
		return new Message();
	}
	@Bean
	public Subject getSubject() {
		return new Subject();
	}

	}

