package com;

import java.io.Serializable;
import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.config.EmailConfig;

public class Email{
	
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(EmailConfig.class);
		
		To to = context.getBean(To.class);
		to.setToEmail("xyz@gmail.com");
		to.setToName("Revi");
		
		From from = context.getBean(From.class);
		from.setFromEmail("abc@gmail.com");
		from.setFromName("Rohan");
		
		Subject subject = context.getBean(Subject.class);
		subject.setCaption("Hello");
		
		Message message = context.getBean(Message.class);
		message.setBodyContent("Hello, Nice to meet you");
		
		System.out.println(to);
		System.out.println(from);
		System.out.println(subject);
		System.out.println(message);	
		
		
	}
}