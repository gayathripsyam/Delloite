package html.pages;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class EnterProducts
 */
public class EnterProducts extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EnterProducts() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletresp resp)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletresp resp)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
		
	}
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.getWriter().println("<h1>Product Details</h1>");
		resp.getWriter().println("<form action='ProductServer' method:'get'><table>");
		resp.getWriter().println("<tr><td>Enter Product Id:</td><td><input type='text' name='PID' id='pid'></td></tr><br/>");
		resp.getWriter().println("<tr><td>Enter Product Name:</td><td><input type='text' name='PName' id='pname'></td></tr><br/>");
		resp.getWriter().println("<tr><td>Enter Product Price:</td> <td><input type='text' name='pprice' id='pprice'></td></tr><br/>");
		resp.getWriter().println("<tr><td>Enter Product Quantity of Hand:</td> <td><input type='text' name='pqoh' id='pqoh'></td></tr><br/>");
		resp.getWriter().println("<tr><td>Want to add more?</td><td><input type='submit' value='Submit' onClick=''></td></tr>");
		resp.getWriter().println("</table></form>");
	
		resp.getWriter().println("<a href='ViewProducts'>View all Products stored...</a>");
		
	}
}
