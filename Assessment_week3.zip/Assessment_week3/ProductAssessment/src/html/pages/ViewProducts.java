package html.pages;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Iterator;

import com.Product.Product;
import com.cms.deloitte.dao.impl.ProductDAOImpl;

/**
 * Servlet implementation class ViewProducts
 */
public class ViewProducts extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewProducts() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	// TODO Auto-generated method stub
       ProductDAOImpl productdaoimpl=new ProductDAOImpl();
       List<Product> list=productdaoimpl.listProducts();
       resp.getWriter().println("ProductId  "+"ProductName  "+"ProductPrice  "+"QuantityOfHand <br/>");
       Iterator iterator=list.iterator();
       while(iterator.hasNext())
       {   resp.getWriter().println(iterator.next() + "");
       }
    }

}
