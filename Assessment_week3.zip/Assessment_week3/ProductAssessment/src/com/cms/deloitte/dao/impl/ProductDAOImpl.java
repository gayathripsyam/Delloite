package com.cms.deloitte.dao.impl;

import java.io.IOException;

import org.hibernate.*;

import java.util.List;

import org.hibernate.cfg.Configuration;
import org.hibernate.Session;
import org.hibernate.*;
import org.hibernate.transaction.*;

import com.cms.deloitte.dao.ProductDAO;
import com.Product.*;

public class ProductDAOImpl implements ProductDAO{

	Configuration configuration=new Configuration().configure();
	SessionFactory factory=configuration.buildSessionFactory();

	
	public boolean addProduct(Product Product) {
		Session session = factory.openSession();
		
		Transaction transcation = session.beginTransaction();
		session.save(Product);
		transcation.commit();
		return true;
	}
	
	public List<Product> listProducts() {
		Session session=factory.openSession();
		Query query=session.createQuery("from Product");
		return query.list();
		// TODO Auto-generated method stub
	}
}
