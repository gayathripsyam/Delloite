package com.Product;
import java.util.Scanner;

public class Product{
	
	private int pid;
	private String pname;
	private int qoh;
	private int price;
	
	public Product()
	{
		
	}
	
	public Product(int pid, String pname, int qoh, int price) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.qoh = qoh;
		this.price = price;
	}
	
	public void acceptProductDetails()
	{
	 Scanner input=new Scanner(System.in);
	 System.out.println("Enter the Product ID:");
	 this.pid=input.nextInt();
	 System.out.println("Enter the Product Name:");
	 this.pname=input.next();
	 System.out.println("Enter the Product Price:");
	 this.price=input.nextInt();
	 System.out.println("Enter the quantity of hand:");
	 this.qoh=input.nextInt();
	}
	
	public void updateProductDetails(int id)
	{
		 Scanner input=new Scanner(System.in); 
		 System.out.println("Enter the Updated Product Name:");
		 this.pname=input.next();
		 System.out.println("Enter the Updated Product Price:");
		 this.price=input.nextInt();
		 System.out.println("Enter the Updated Quantity of hand:");
		 this.qoh=input.nextInt();
		
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getQoh() {
		return qoh;
	}
	public void setQoh(int qoh) {
		this.qoh = qoh;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return  pid + "  " + pname + " " + qoh + " " + price + " ";
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + pid;
		result = prime * result + ((pname == null) ? 0 : pname.hashCode());
		result = prime * result + price;
		result = prime * result + qoh;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (pid != other.pid)
			return false;
		if (pname == null) {
			if (other.pname != null)
				return false;
		} else if (!pname.equals(other.pname))
			return false;
		if (price != other.price)
			return false;
		if (qoh != other.qoh)
			return false;
		return true;
	}
	
	
	
	
}
