package com.cms.deloitte.client;

import java.util.Scanner;

import com.cms.deloitte.daoimpl.CustomerDAOimpl;
import com.cms.deloitte.model.Customer;

public class LaunchCustomerApplication {

	public static void startCustomerApp() {
		
		System.out.println("##### Welcome to Customer App #####");
		System.out.println("##### 1) Add Customer #####");
		System.out.println("##### 2) Update Customer #####");
		System.out.println("##### 3) Delete Customer #####");
		System.out.println("##### 4)#####");
		System.out.println("##### 5)#####");
		System.out.println("##### 6) Exit #####");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choices from 1-6");
		int choice = sc.nextInt();
		
		if(choice==1) {
			Customer customer = new Customer();
			customer.acceptCustomerDetails();
			CustomerDAOimpl impl = new CustomerDAOimpl();
			boolean result = impl.addCustomer(customer);
			System.out.println(result);
			
		}
		
		if(choice==6) {
			System.exit(0);
		}
		
	}
}
