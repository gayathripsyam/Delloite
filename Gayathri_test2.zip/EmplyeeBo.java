package Assessment2;


public class EmplyeeBo {

	public void calincomeTax(EmplyeeVo e) {
		
		double a = e.getAnnualIncome();
		if(a<500000) {
			e.setAnnualTax(0);
		}
		else if(a<500000)
		{
			e.setAnnualTax(0.1*a);
		}
		else
		{
			e.setAnnualTax(0.2*a);
		}
		
		
	}
}
