import java.util.Scanner;


public abstract class Arithmetic {
	abstract int calc(int x, int y);	
}

 class Addition extends Arithmetic {
	@Override
	public int calc(int a, int b) {
		return a+b;
	}
}

class Subtraction extends Arithmetic {
		@Override
		public int calc(int x, int y) {
			return x-y;
		}
}

class Multiplication extends Arithmetic {
	@Override
	public int calc(int x, int y) {
		return x*y;
	}

}

class Division extends Arithmetic {
	@Override
	public int calc(int x, int y) {
		return (int)x/y;
	}
}

class Exit extends Arithmetic {
	@Override
	public int calc(int x, int y) {
		System.exit(0);
		return 0;
	}

}

class Calculator {

	public static void main(String[] args) {
		
		Object[] calculation = {new Addition(), new Subtraction(), new Multiplication(), new Division(), new Exit()};
		System.out.println("Press 1 for Addition");
		System.out.println("Press 2 for Subtraction");
		System.out.println("Press 3 for Multiplication");
		System.out.println("Press 4 for Division");
		System.out.println("Press 5 to Exit");
		int input;
		Scanner sc = new Scanner(System.in);
		input = sc.nextInt();
		int num1, num2;//  = 12, num2 = 6;
		System.out.println("Enter the first number: ");
		num1 = sc.nextInt();
		System.out.println("Enter the second number: ");
		num2 = sc.nextInt();
		int y = ((Arithmetic)calculation[input-1]).calc(num1, num2);
		System.out.println("Result is: " +y);
		sc.close();

	}
}
