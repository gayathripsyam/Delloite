package Assessment2;

import java.util.Scanner;

public class EmplyeeVo {

	//Variable Creation
	int employeeId;
	String employeeName;
	int annualIncome;
	int annualTax;
	
	//Getters and Setters
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getAnnualIncome() {
		return annualIncome;
	}
	public void setAnnualIncome(int annualIncome) {
		this.annualIncome = annualIncome;
	}
	public int getAnnualTax() {
		return annualTax;
	}
	public void setAnnualTax(int annualTax) {
		this.annualTax = annualTax;
	}
	
	
	//Hashcode and equals
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + annualIncome;
		result = prime * result + annualTax;
		result = prime * result + employeeId;
		result = prime * result + ((employeeName == null) ? 0 : employeeName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmplyeeVo other = (EmplyeeVo) obj;
		if (annualIncome != other.annualIncome)
			return false;
		if (annualTax != other.annualTax)
			return false;
		if (employeeId != other.employeeId)
			return false;
		if (employeeName == null) {
			if (other.employeeName != null)
				return false;
		} else if (!employeeName.equals(other.employeeName))
			return false;
		return true;
	}
	

	//toString
	@Override
	public String toString() {
		return "EmplyeeVo [employeeId=" + employeeId + ", employeeName=" + employeeName + ", annualIncome="
				+ annualIncome + ", annualTax=" + annualTax + "]";
	}
	
	
	
	 
}
