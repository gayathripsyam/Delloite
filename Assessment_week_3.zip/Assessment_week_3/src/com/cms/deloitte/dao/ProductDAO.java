package com.cms.deloitte.dao;

import java.util.List;

import com.cms.deloitte.model.Product;

	public interface ProductDAO {


					public boolean deleteProduct(int productId);			
					public List<Product> listProducts();
					public Product findProduct(int productId);
					public boolean isProductExists(int productId);
					boolean addProduct(Product product);
					boolean updateProduct(Product product);
					List<Product> listproducts();					
		}
