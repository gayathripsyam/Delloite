package com.cms.deloitte.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cms.deloitte.dao.ProductDAO;
import com.cms.deloitte.dao.impl.ProductDAOimpl;
import com.cms.deloitte.dao.ProductDAO;
import com.cms.deloitte.model.Product;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/ProductServlet")
public class ProductServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.getWriter().println("Enjoy Shopping!!");
		int productId=Integer.parseInt(request.getParameter("productId"));
		String productName=request.getParameter("productName");
		String productQuantity=request.getParameter("productQuantity");
		int productPrice=Integer.parseInt(request.getParameter("productPrice"));
		System.out.println("hi");
		response.getWriter().println(productId);
        response.getWriter().println(productName);
		response.getWriter().println(productQuantity);
		response.getWriter().println(productPrice);
		
		response.getWriter().print("<br/>"+productId);
		response.getWriter().print("<br/>"+ productName);
		response.getWriter().print("<br/>"+productQuantity);
		response.getWriter().print("<br/>"+productPrice); 
		
		ProductDAO productDAO=new ProductDAOimpl();
	    Product product=new Product();
		
		productDAO.addProduct(product);
		
		// TODO Auto-generated method stub
	}

}
