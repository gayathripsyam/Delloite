package com;

public class ContactDetails {

	private String mobileNumber;
	private String mailId;

	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String string) {
		this.mobileNumber = string;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	@Override
	public String toString() {
		return "ContactDetails [mobileNumber=" + mobileNumber + ", mailId=" + mailId + "]";
	}
	

}
